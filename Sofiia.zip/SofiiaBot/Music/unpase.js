player.pause();

// Unpause after 5 seconds
setTimeout(() => player.unpause(), 5_000)